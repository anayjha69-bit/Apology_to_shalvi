# Hey Babe 💗 — apology microsite

## Deploy on Vercel
1. Upload `index.html` to the root of a GitHub repository.
2. Import the repository at https://vercel.com/new
3. Deploy as a static site. No build command or framework is needed.
4. Share the generated `.vercel.app` URL.

The page is responsive and has 8 interactive screens. It uses Google Fonts if the visitor is online; system fonts will be used as fallback.
